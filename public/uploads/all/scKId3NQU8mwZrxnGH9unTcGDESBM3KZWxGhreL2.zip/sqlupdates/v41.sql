UPDATE `settings` SET `value` = '4.1' WHERE `settings`.`type` = 'current_version';

COMMIT;