UPDATE `settings` SET `value` = '4.8' WHERE `settings`.`type` = 'current_version';

COMMIT;