UPDATE `settings` SET `value` = '3.2' WHERE `settings`.`type` = 'current_version';

COMMIT;
