UPDATE `settings` SET `value` = '4.2' WHERE `settings`.`type` = 'current_version';

COMMIT;